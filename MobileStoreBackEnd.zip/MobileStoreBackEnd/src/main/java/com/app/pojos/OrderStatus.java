package com.app.pojos;

public enum OrderStatus {
	
	Order_Placed,Order_Despached,Order_Delivered

}
